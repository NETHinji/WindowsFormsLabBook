﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsLabBook_161363_Labs
{
    public partial class NetEditor : Form
    {
        public NetEditor()
        {
            InitializeComponent();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NetEditorChild nec = new NetEditorChild();
            nec.Text = "New Document"; nec.MdiParent = this;
            nec.Show();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ActiveMdiChild != null)
                this.ActiveMdiChild.Close();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Text Files|*.txt|XML Files|*.xml";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                StreamReader sr = new StreamReader(File.OpenRead(openFileDialog1.FileName));
                NetEditorChild nec = new NetEditorChild();
                nec.Text = openFileDialog1.FileName;
                nec.textBox1.Text = sr.ReadToEnd();
                sr.Close();
                nec.MdiParent = this;
                nec.Show();
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "Text Files|*.txt|XML Files|*.xml";
            NetEditorChild nec = null;
            saveFileDialog1.ShowDialog();
            if (this.ActiveMdiChild != null)
                nec=(NetEditorChild)this.ActiveMdiChild;
            if (saveFileDialog1.FileName != null)
            {
                File.WriteAllText(saveFileDialog1.FileName, nec.textBox1.Text);
            }
        }
        
    }
}
