﻿namespace WindowsFormsLabBook_161363_Labs
{
    partial class RegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtbirthdate = new System.Windows.Forms.TextBox();
            this.btnRegistration = new System.Windows.Forms.Button();
            this.imgcal = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.imgcal)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(121, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(121, 146);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Birth Date";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(202, 77);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(189, 20);
            this.txtname.TabIndex = 2;
            // 
            // txtbirthdate
            // 
            this.txtbirthdate.Location = new System.Drawing.Point(204, 139);
            this.txtbirthdate.Name = "txtbirthdate";
            this.txtbirthdate.Size = new System.Drawing.Size(187, 20);
            this.txtbirthdate.TabIndex = 3;
            // 
            // btnRegistration
            // 
            this.btnRegistration.Location = new System.Drawing.Point(181, 217);
            this.btnRegistration.Name = "btnRegistration";
            this.btnRegistration.Size = new System.Drawing.Size(118, 44);
            this.btnRegistration.TabIndex = 5;
            this.btnRegistration.Text = "Register";
            this.btnRegistration.UseVisualStyleBackColor = true;
            this.btnRegistration.Click += new System.EventHandler(this.btnRegistration_Click);
            // 
            // imgcal
            // 
            this.imgcal.Image = global::WindowsFormsLabBook_161363_Labs.Properties.Resources.cal;
            this.imgcal.InitialImage = null;
            this.imgcal.Location = new System.Drawing.Point(397, 134);
            this.imgcal.Name = "imgcal";
            this.imgcal.Size = new System.Drawing.Size(22, 25);
            this.imgcal.TabIndex = 4;
            this.imgcal.TabStop = false;
            this.imgcal.Click += new System.EventHandler(this.imgcal_Click);
            this.imgcal.DoubleClick += new System.EventHandler(this.imgcal_DoubleClick);
            // 
            // RegistrationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnRegistration);
            this.Controls.Add(this.imgcal);
            this.Controls.Add(this.txtbirthdate);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "RegistrationForm";
            this.Text = "RegistrationForm";
            this.Load += new System.EventHandler(this.RegistrationForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.imgcal)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.PictureBox imgcal;
        private System.Windows.Forms.Button btnRegistration;
        public System.Windows.Forms.TextBox txtbirthdate;
    }
}