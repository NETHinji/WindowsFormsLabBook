﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsLabBook_161363_Labs
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnWelcome_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Welcome " + txtName.Text + " !!!");
        }

        private void btnWelcome_MouseEnter(object sender, EventArgs e)
        {
            //sender is source of event ie: btnwelcome button.
            Button b = sender as Button;
            b.BackColor = Color.Yellow;
            b.ForeColor = Color.OrangeRed;
        }

        private void btnWelcome_MouseLeave(object sender, EventArgs e)
        {
            //sender is source of event ie: btnwelcome button.
            Button b = sender as Button;
            b.BackColor = SystemColors.Control;
            b.ForeColor = Color.Black;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnClose.Click += BtnClose_Click;
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtName_MouseEnter(object sender, EventArgs e)
        {
            txtName.BackColor = Color.Yellow;
        }
    }
}
