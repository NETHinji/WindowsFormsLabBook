﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsLabBook_161363_Labs
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }

        private void RegistrationForm_Load(object sender, EventArgs e)
        {
        }

        private void imgcal_Click(object sender, EventArgs e)
        {
            CalendarDialog cal = new CalendarDialog();
            date_change(cal);
            
        }

        private void btnRegistration_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Registered Successfully!!!!!");
        }

        private void imgcal_DoubleClick(object sender, EventArgs e)
        {

        }
        private void date_change(CalendarDialog cd)
        {
            cd.ShowDialog();
                txtbirthdate.Text = cd.DateSelection.SelectionStart.ToString("dd-MM-yyyy");
        }
    }
}
